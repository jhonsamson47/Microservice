package com.hcl.springboot.microservice.currencyconversion.springbootmicroservicecc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicroserviceCcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicroserviceCcApplication.class, args);
	}
}
